import { VersionedTransaction, Connection } from '@solana/web3.js';
import { searcherClient } from '@solsdk/jito-ts/dist/sdk/block-engine/searcher';
import { Bundle } from '@solsdk/jito-ts/dist/sdk/block-engine/types';
import { config } from '../utils/config';
import { logger } from '../utils/logger';

// Initialize Standard RPC Connection
const connection = new Connection(config.RPC_ENDPOINT, {
  wsEndpoint: config.RPC_WEBSOCKET,
  commitment: 'processed'
});

// Initialize Jito Client
const jitoSearcher = searcherClient(
  config.JITO_BLOCK_ENGINE,
  config.JITO_AUTH as any
);

export async function submitTransactionWithRacing(transaction: VersionedTransaction) {
  logger.info('Racing transaction execution across multiple providers...');

  // 1. Jito Block Engine Bundle
  const submitToJitoBundle = async () => {
    try {
      const b = new Bundle([transaction], 1); 
      const resp = await jitoSearcher.sendBundle(b);
      return { success: true, provider: 'jito-bundle', result: resp };
    } catch (e: any) {
      return { success: false, provider: 'jito-bundle', error: e.message };
    }
  };

  // 2. Standard RPC Node
  const submitToRpc = async () => {
    try {
      const rawTx = transaction.serialize();
      const signature = await connection.sendRawTransaction(rawTx, {
        skipPreflight: true,
        maxRetries: 0
      });
      return { success: true, provider: 'rpc', signature };
    } catch (e: any) {
      return { success: false, provider: 'rpc', error: e.message };
    }
  };

  // Run the race
  const results = await Promise.allSettled([
    submitToJitoBundle(),
    submitToRpc()
  ]);

  results.forEach(res => {
    if (res.status === 'fulfilled') {
      if (res.value.success) {
        logger.info(`Transaction submitted successfully via ${res.value.provider}`);
      } else {
        logger.warn(`Failed to submit via ${res.value.provider}: ${res.value.error}`);
      }
    } else {
      logger.error('Provider submission rejected:', res.reason);
    }
  });

  return results;
}
