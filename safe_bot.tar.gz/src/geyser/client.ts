import { config } from '../utils/config';
import { logger } from '../utils/logger';
import { EventEmitter } from 'events';

export async function createGeyserClient() {
  const endpoint = config.GEYSER_ENDPOINT;
  const token = config.GEYSER_API_TOKEN;

  logger.info(`Connecting to Geyser at: ${endpoint}`);
  
  try {
    const Client = require('@triton-one/yellowstone-grpc').default || require('@triton-one/yellowstone-grpc');
    const client = new Client(endpoint, token, undefined);
    await client.connect();
    
    const stream = await client.subscribe();
    
    stream.write({
      accounts: {
        jupiter: {
          account: [],
          owner: ["JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4"],
          filters: [],
        }
      },
      commitment: 1, // Processed
    });

    logger.info("Successfully connected and subscribed to Geyser stream.");

    return { client, stream };
  } catch (error: any) {
    if (error.code === 'MODULE_NOT_FOUND' || (error.message && error.message.includes('native binding'))) {
        logger.warn("Native Yellowstone gRPC bindings skipped. Injecting MOCK Geyser Stream to verify local structure.");
        
        const mockStream = new EventEmitter();
        (mockStream as any).write = (req: any) => {
            logger.info("[MOCK] Sent subscription request to Geyser.");
        };

        // Emit a fake Jupiter account update every 3 seconds for testing the pipeline
        setInterval(() => {
            logger.info("[MOCK] Injecting simulated Jupiter account update from Geyser.");
            mockStream.emit('data', {
                filters: ['jupiter'],
                account: {
                    account: {
                        pubkey: Buffer.from("MOCK_PUBKEY_JUPITER")
                    }
                }
            });
        }, 3000);

        return { client: null, stream: mockStream };
    }
    
    logger.error("Failed to connect to Geyser stream:", error);
    throw error;
  }
}
