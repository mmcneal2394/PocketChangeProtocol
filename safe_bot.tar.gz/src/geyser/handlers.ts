import { logger } from '../utils/logger';
import { fetchJupiterQuote, getParallelSwapInstructions } from '../jupiter/quotes';
import { buildVersionedTransaction } from '../execution/transaction';
import { submitTransactionWithRacing } from '../execution/racing';
import { config } from '../utils/config';

// ArbitraSaaS Engine Historical Tokens
const TOKENS = {
  WSOL: "So11111111111111111111111111111111111111112",
  USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  WIF: "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYtM2wYSzRo",
  BONK: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  RAY: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R"
};

const TRADE_ROUTES = [
  [TOKENS.WSOL, TOKENS.USDC],
  [TOKENS.WSOL, TOKENS.WIF],
  [TOKENS.WSOL, TOKENS.BONK],
  [TOKENS.WSOL, TOKENS.RAY]
];

// Anti-spam throttling limit to protect public Jupiter API
let lastQuoteTime = 0;
const QUOTE_COOLDOWN_MS = 2000;

export async function handleAccountUpdate(data: any) {
  const now = Date.now();
  if (now - lastQuoteTime < QUOTE_COOLDOWN_MS) {
    return; // Rate limited, skip this structural update
  }
  
  if (process.env.DEBUG) {
    logger.debug(`[GEYSER] Stream triggered account update event.`);
  }

  lastQuoteTime = now;

  // Select a random route from the ArbitraSaaS dataset
  const route = TRADE_ROUTES[Math.floor(Math.random() * TRADE_ROUTES.length)];
  const inputMint = route[0];
  const intermediateMint = route[1];
  
  // Base input: 0.5 SOL in Lamports
  const tradeSize = 0.5 * 10 ** 9; 

  logger.info(`🔍 [ARBITRAGE] Hunting loop activated for simulated route: SOL -> ${intermediateMint.substring(0, 4)}...`);

  // Leg 1: SOL -> Token
  const quote1 = await fetchJupiterQuote(inputMint, intermediateMint, tradeSize);
  if (!quote1) return;

  // Leg 2: Token -> SOL
  const intermediateAmount = Number(quote1.outAmount);
  const quote2 = await fetchJupiterQuote(intermediateMint, inputMint, intermediateAmount);
  if (!quote2) return;

  const expectedOut = Number(quote2.outAmount);
  const profitLamports = expectedOut - tradeSize;
  const profitBps = (profitLamports / tradeSize) * 10000;

  if (profitBps > 0) {
    logger.info(`✅ [ARBITRAGE FOUND] Profit: ${profitBps.toFixed(2)} bps (${(profitLamports / 10**9).toFixed(5)} SOL)`);
  } else {
    logger.debug(`❌ [NO ARBITRAGE] Loss: ${profitBps.toFixed(2)} bps. Target minimum is ${config.MIN_PROFIT_BPS} bps.`);
  }

  if (profitBps >= config.MIN_PROFIT_BPS) {
    logger.warn(`🔥 PROFITABLE OPPORTUNITY DETECTED! Proceeding to bundle extraction...`);
    
    const instructions = await getParallelSwapInstructions(quote1, quote2);
    if (!instructions) {
      logger.error('Failed to get routing instructions.');
      return;
    }

    const transaction = await buildVersionedTransaction(instructions.ix1, instructions.ix2);
    if (!transaction) {
      logger.error('Failed to build versioned transaction.');
      return;
    }

    // Submit transaction via Jito Bundle & RPC asynchronously
    await submitTransactionWithRacing(transaction);
  }
}

export function startGeyserListeners(stream: any) {
  stream.on('data', (data: any) => {
    try {
      if (data.filters && data.filters.includes('jupiter')) {
        handleAccountUpdate(data);
      }
    } catch (err) {
      logger.error('Error handling geyser message', err);
    }
  });

  stream.on('error', (err: any) => {
    logger.error('Geyser stream error', err);
  });

  stream.on('end', () => {
    logger.warn('Geyser stream ended. Consider reconnecting.');
  });
}
