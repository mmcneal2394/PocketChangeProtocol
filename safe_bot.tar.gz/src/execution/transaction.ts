import { PublicKey, TransactionInstruction, VersionedTransaction, TransactionMessage, Keypair, SystemProgram, AddressLookupTableAccount } from '@solana/web3.js';
import * as fs from 'fs';
import { getAddressLookupTable, getCachedBlockhash } from '../jupiter/cache';
import { config } from '../utils/config';
import { logger } from '../utils/logger';

export async function buildVersionedTransaction(ix1Response: any, ix2Response: any) {
  try {
    const rawKeypair = JSON.parse(fs.readFileSync(config.WALLET_KEYPAIR_PATH, 'utf-8'));
    const wallet = Keypair.fromSecretKey(new Uint8Array(rawKeypair));

    const blockhash = getCachedBlockhash();
    if (!blockhash) {
      throw new Error('No cached blockhash available');
    }

    const instructions: TransactionInstruction[] = [];

    // Helper to deserialize Jupiter's returned instruction
    const deserializeInstruction = (ix: any) => {
      if (!ix) return null;
      return new TransactionInstruction({
        programId: new PublicKey(ix.programId),
        keys: ix.accounts.map((key: any) => ({
          pubkey: new PublicKey(key.pubkey),
          isSigner: key.isSigner,
          isWritable: key.isWritable,
        })),
        data: Buffer.from(ix.data, "base64"),
      });
    };

    // Load necessary address lookup tables
    const altsToFetch = [
      ...(ix1Response.addressLookupTableAddresses || []),
      ...(ix2Response.addressLookupTableAddresses || [])
    ];

    const altsRaw = await Promise.all(
      Array.from(new Set(altsToFetch)).map(addr => getAddressLookupTable(addr as string))
    );
    const alts: AddressLookupTableAccount[] = altsRaw.filter(alt => alt !== null) as AddressLookupTableAccount[];

    // Add Ix1 instructions
    if (ix1Response.setupInstructions) {
      ix1Response.setupInstructions.forEach((ix: any) => instructions.push(deserializeInstruction(ix)!));
    }
    instructions.push(deserializeInstruction(ix1Response.swapInstruction)!);
    if (ix1Response.cleanupInstruction) {
      instructions.push(deserializeInstruction(ix1Response.cleanupInstruction)!);
    }

    // Add Ix2 instructions
    if (ix2Response.setupInstructions) {
      ix2Response.setupInstructions.forEach((ix: any) => instructions.push(deserializeInstruction(ix)!));
    }
    instructions.push(deserializeInstruction(ix2Response.swapInstruction)!);
    if (ix2Response.cleanupInstruction) {
      instructions.push(deserializeInstruction(ix2Response.cleanupInstruction)!);
    }

    // Add Jito tip instruction
    const tipAccount = new PublicKey("96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5");
    instructions.push(
      SystemProgram.transfer({
        fromPubkey: wallet.publicKey,
        toPubkey: tipAccount,
        lamports: config.JITO_TIP_AMOUNT
      })
    );

    const messageV0 = new TransactionMessage({
      payerKey: wallet.publicKey,
      recentBlockhash: blockhash,
      instructions,
    }).compileToV0Message(alts);

    const transaction = new VersionedTransaction(messageV0);
    transaction.sign([wallet]);

    return transaction;
  } catch (error) {
    logger.error('Failed to build versioned transaction:', error);
    return null;
  }
}
