import { VersionedTransaction, Connection } from '@solana/web3.js';
import { config } from '../utils/config';
import { logger } from '../utils/logger';

// Initialize Standard RPC Connection securely without any malware dependencies
const connection = new Connection(config.RPC_ENDPOINT, {
  wsEndpoint: config.RPC_WEBSOCKET,
  commitment: 'processed'
});

export async function submitTransactionWithRacing(transaction: VersionedTransaction) {
  logger.info('Executing transaction securely via Standard RPC Node...');

  // Standard RPC Node Fallback
  const submitToRpc = async () => {
    try {
      const rawTx = transaction.serialize();
      const signature = await connection.sendRawTransaction(rawTx, {
        skipPreflight: true,
        maxRetries: 0
      });
      return { success: true, provider: 'rpc', signature };
    } catch (e: any) {
      return { success: false, provider: 'rpc', error: e.message };
    }
  };

  // Only submit securely using the RPC provider due to malware alert in previous spec
  const results = await Promise.allSettled([
    submitToRpc()
  ]);

  results.forEach(res => {
    if (res.status === 'fulfilled') {
      if (res.value.success) {
        logger.info(`Transaction submitted successfully! Signature: ${res.value.signature}`);
      } else {
        logger.warn(`Failed to submit via RPC: ${res.value.error}`);
      }
    } else {
      logger.error('Provider submission rejected:', res.reason);
    }
  });

  return results;
}
