import { z } from 'zod';
import dotenv from 'dotenv';
dotenv.config();

const envSchema = z.object({
  GEYSER_ENDPOINT: z.string().url().or(z.string()),
  GEYSER_API_TOKEN: z.string(),
  RPC_ENDPOINT: z.string().url(),
  RPC_WEBSOCKET: z.string().url(),

  JITO_AUTH: z.string().optional(),
  JITO_BLOCK_ENGINE: z.string().url(),
  JITO_TIP_AMOUNT: z.string().transform(Number),

  JUPITER_ENDPOINT: z.string().url(),

  WALLET_KEYPAIR_PATH: z.string(),
  WALLET_PUBLIC_KEY: z.string(),

  SLIPPAGE_BPS: z.string().transform(Number),
  MIN_PROFIT_BPS: z.string().transform(Number),
  MAX_TRADE_SIZE_SOL: z.string().transform(Number),
  RESTRICT_INTERMEDIATE_TOKENS: z.union([z.boolean(), z.string().transform((s) => s === 'true')]).default(true),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error("Invalid environment variables");
  console.error(parsed.error.format());
  process.exit(1);
}

export const config = parsed.data;
