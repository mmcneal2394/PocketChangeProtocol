import { createJupiterApiClient } from '@jup-ag/api';
import { config } from '../utils/config';
import { logger } from '../utils/logger';

const jupiter = createJupiterApiClient({ basePath: config.JUPITER_ENDPOINT });

export async function fetchJupiterQuote(inputToken: string, outputToken: string, amount: number) {
  try {
    const quoteResponse = await jupiter.quoteGet({
      inputMint: inputToken,
      outputMint: outputToken,
      amount: amount,
      slippageBps: config.SLIPPAGE_BPS,
      restrictIntermediateTokens: config.RESTRICT_INTERMEDIATE_TOKENS,
    });
    return quoteResponse;
  } catch (error) {
    logger.error('Failed to fetching Jupiter quote:', error);
    return null;
  }
}

export async function getParallelSwapInstructions(quote1: any, quote2: any) {
  try {
    const [ix1, ix2] = await Promise.all([
      jupiter.swapInstructionsPost({
        swapRequest: {
          quoteResponse: quote1,
          userPublicKey: config.WALLET_PUBLIC_KEY,
          wrapAndUnwrapSol: true,
        }
      }),
      jupiter.swapInstructionsPost({
        swapRequest: {
          quoteResponse: quote2,
          userPublicKey: config.WALLET_PUBLIC_KEY,
          wrapAndUnwrapSol: true,
        }
      })
    ]);
    return { ix1, ix2 };
  } catch (error) {
    logger.error('Failed to get swap instructions in parallel:', error);
    return null;
  }
}
