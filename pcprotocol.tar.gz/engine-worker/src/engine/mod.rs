use solana_sdk::{
    instruction::{Instruction, AccountMeta},
    message::Message,
    pubkey::Pubkey,
    signature::{Keypair, Signer},
    system_instruction,
    transaction::Transaction,
};
use sha2::{Sha256, Digest};

/// Computes the 8-byte discriminator for Anchor instructions
pub fn get_discriminator(name: &str) -> [u8; 8] {
    let mut hasher = Sha256::new();
    hasher.update(format!("global:{}", name));
    let hash = hasher.finalize();
    let mut discriminator = [0u8; 8];
    discriminator.copy_from_slice(&hash[0..8]);
    discriminator
}

/// The VaultExecutor encapsulates interactions directly with the PocketChange Vault PDA.
/// It wraps raw decentralized exchange swap instructions securely between `borrow` and `process` calls
/// securing the pool from un-returned flash-loans and auto-compounding the arbitrage profit.
pub struct VaultExecutor {
    pub admin: Keypair,
    pub program_id: Pubkey,
    pub token_program: Pubkey,
}

impl VaultExecutor {
    pub fn new(admin: Keypair, program_id: Pubkey, token_program: Pubkey) -> Self {
        VaultExecutor {
            admin,
            program_id,
            token_program,
        }
    }

    pub fn build_vault_ptb(
        &self,
        vault_state: Pubkey,
        vault_usdc: Pubkey,
        admin_usdc: Pubkey,
        treasury_usdc: Pubkey,
        borrow_amount: u64,
        reported_profit: u64,
        swap_instructions: Vec<Instruction>,
        jito_tip_lamports: u64
    ) -> Result<Vec<Instruction>, String> {
        
        let mut ixs = Vec::new();

        // 0. Compute Budget & Priority Fees (Gas optimization for execution speed)
        ixs.push(solana_sdk::compute_budget::ComputeBudgetInstruction::set_compute_unit_limit(500_000));
        ixs.push(solana_sdk::compute_budget::ComputeBudgetInstruction::set_compute_unit_price(5_000_000));

        // 0.5. Jito MEV Tip Injection (Vector 1: Cryptographic Jitter)
        use std::str::FromStr;
        use rand::{Rng, RngExt};
        let mut rng = rand::rng();
        let jitter = rng.random_range(1..=50_000);
        let randomized_jito_tip = jito_tip_lamports + jitter;

        let jito_tip_account = Pubkey::from_str("96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5").unwrap();
        ixs.push(system_instruction::transfer(&self.admin.pubkey(), &jito_tip_account, randomized_jito_tip));

        // 1. Borrow Instruction
        let mut borrow_data = get_discriminator("borrow_for_arbitrage").to_vec();
        borrow_data.extend_from_slice(&borrow_amount.to_le_bytes()); // amount

        ixs.push(Instruction {
            program_id: self.program_id,
            accounts: vec![
                AccountMeta::new(self.admin.pubkey(), true),
                AccountMeta::new(vault_state, false),
                AccountMeta::new(vault_usdc, false),
                AccountMeta::new(admin_usdc, false),
                AccountMeta::new_readonly(self.token_program, false),
            ],
            data: borrow_data,
        });

        // 2. Insert Core Swaps (e.g. Jupiter, Raydium, Orca)
        ixs.extend(swap_instructions);

        // 3. Process Profit Instruction (Returns principal recursively + compounds generated profit)
        let mut process_data = get_discriminator("process_arbitrage").to_vec();
        process_data.extend_from_slice(&reported_profit.to_le_bytes()); // total_profit

        ixs.push(Instruction {
            program_id: self.program_id,
            accounts: vec![
                AccountMeta::new(self.admin.pubkey(), true),
                AccountMeta::new(vault_state, false),
                AccountMeta::new(vault_usdc, false),
                AccountMeta::new(treasury_usdc, false),
                AccountMeta::new_readonly(self.token_program, false),
            ],
            data: process_data,
        });

        println!("[PocketChange] Assembled Payload: Borrow {} USDC -> N Swaps -> Return + {} USDC", borrow_amount, reported_profit);
        Ok(ixs)
    }

    pub async fn fetch_jupiter_swap(&self, input_mint: &str, output_mint: &str, amount: u64) -> Result<serde_json::Value, String> {
        // Return a statically mocked response due to simulated sandbox constraints
        
        let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as u64;
        // Add pseudo-random market noise between 0.98 and 1.02
        let noise = (now % 40) as f64 / 1000.0; // 0.00 to 0.04
        let slippage = 0.98 + noise;
        
        // Mock token price conversions assuming 1 USDC = 1 USD
        // WIF = ~$3.00, BONK = ~$0.00002, SOL = ~$150, JUP = ~$0.80
        let conversion_rate = match (input_mint, output_mint) {
            // USDC -> Token
            ("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm") => 0.33,  // WIF
            ("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "So11111111111111111111111111111111111111112") => 0.0066, // SOL
            ("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbAbdMdEqtXk") => 1.25,   // JUP
            ("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263") => 50000.0, // BONK

            // Token -> USDC
            ("EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm", "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v") => 3.03, // WIF
            ("So11111111111111111111111111111111111111112", "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v") => 151.5, // SOL
            ("JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbAbdMdEqtXk", "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v") => 0.80,  // JUP
            ("DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263", "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v") => 0.00002, // BONK

            // Token -> Token (Intermediate legs)
            ("EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm", "So11111111111111111111111111111111111111112") => 0.02, // WIF -> SOL
            ("So11111111111111111111111111111111111111112", "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbAbdMdEqtXk") => 187.5, // SOL -> JUP
            ("DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263", "So11111111111111111111111111111111111111112") => 0.00000013, // BONK -> SOL
            ("JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbAbdMdEqtXk", "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm") => 0.26, // JUP -> WIF
            _ => 1.0, // Fallback identity
        };

        let out_amount = (amount as f64 * conversion_rate * slippage) as u64;

        Ok(serde_json::json!({
            "inputMint": input_mint,
            "outputMint": output_mint,
            "inAmount": format!("{}", amount),
            "outAmount": format!("{}", out_amount),
            "priceImpactPct": "0.1",
            "marketInfos": []
        }))
    }

    /// Requests the actual serialized transaction or instruction arrays from Jupiter's execution endpoint
    pub async fn fetch_jupiter_instructions(&self, quote_response: serde_json::Value, user_pubkey: &str) -> Result<Vec<Instruction>, String> {
        // If the quote is our simulated sandbox quote, return mocked instructions directly
        if quote_response["marketInfos"].as_array().map_or(false, |arr| arr.is_empty()) {
            return Ok(vec![Instruction {
                program_id: self.token_program,
                accounts: vec![],
                data: vec![0, 1, 2, 3],
            }]);
        }

        let client = reqwest::Client::new();
        
        let payload = serde_json::json!({
            "quoteResponse": quote_response,
            "userPublicKey": user_pubkey,
            "wrapAndUnwrapSol": true,
            // Optimization for PTBs: request raw swap instructions instead of a fully-baked base64 transaction if possible.
            // Note: Currently calling /swap endpoint directly limits customization, standard PTBs parse /swap-instructions.
        });

        // Hitting the detailed instructions endpoint natively
        let resp = client.post("https://quote-api.jup.ag/v6/swap-instructions")
            .json(&payload)
            .send()
            .await
            .map_err(|e| e.to_string())?;

        if !resp.status().is_success() {
            return Err(format!("Jupiter instructions failed: {}", resp.status()));
        }

        let instructions_data: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
        
        let mut parsed_instructions = Vec::new();

        // Helper to map Jupiter's json representation of pubkey, isSigner, isWritable to solana_sdk AccountMeta
        let parse_account_meta = |acc: &serde_json::Value| -> Result<AccountMeta, String> {
            let pubkey_str = acc["pubkey"].as_str().unwrap_or_default();
            let pubkey = pubkey_str.parse::<Pubkey>().map_err(|_| format!("Invalid pubkey: {}", pubkey_str))?;
            let is_signer = acc["isSigner"].as_bool().unwrap_or(false);
            let is_writable = acc["isWritable"].as_bool().unwrap_or(false);

            if is_writable {
                Ok(AccountMeta::new(pubkey, is_signer))
            } else {
                Ok(AccountMeta::new_readonly(pubkey, is_signer))
            }
        };

        let map_instruction = |ix: &serde_json::Value| -> Result<Instruction, String> {
            let program_id_str = ix["programId"].as_str().unwrap_or_default();
            let program_id = program_id_str.parse::<Pubkey>().map_err(|_| format!("Invalid programId: {}", program_id_str))?;
            
            let data_b64 = ix["data"].as_str().unwrap_or_default();
            let data = base64::Engine::decode(&base64::engine::general_purpose::STANDARD, data_b64).unwrap_or_default();
            
            let accounts_json = ix["accounts"].as_array().ok_or("No accounts array")?;
            let mut accounts = Vec::new();
            for acc in accounts_json {
                accounts.push(parse_account_meta(acc)?);
            }

            Ok(Instruction {
                program_id,
                accounts,
                data,
            })
        };

        // Extract setup instructions (like ATAs)
        if let Some(setup) = instructions_data["setupInstructions"].as_array() {
            for ix in setup {
                parsed_instructions.push(map_instruction(ix)?);
            }
        }
        
        // Extract the target swap ix
        if let Some(swap) = instructions_data["swapInstruction"].as_object() {
            parsed_instructions.push(map_instruction(&serde_json::Value::Object(swap.clone()))?);
        }

        Ok(parsed_instructions)
    }

    /// Primary execution loop wrapper that continually evaluates yield limits
    pub async fn process_loop(&self) {
        println!("[Engine] Jupiter DEX Multipath Poller active. Awaiting arbitrage gaps...");
        
        let db_client = crate::db::DbClient::new().await;

        let usdc_mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"; 
        let wif_mint = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"; 
        let sol_mint = "So11111111111111111111111111111111111111112";
        let jup_mint = "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbAbdMdEqtXk";
        let bonk_mint = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263";

        // Define our supported arbitrage routes (starting and ending in USDC)
        let routes = vec![
            vec![usdc_mint, wif_mint, usdc_mint], // 2-Hop
            vec![usdc_mint, sol_mint, jup_mint, usdc_mint], // 3-hop
            vec![usdc_mint, bonk_mint, sol_mint, usdc_mint], // 3-hop
            vec![usdc_mint, jup_mint, wif_mint, sol_mint, usdc_mint], // 4-hop
        ];

        // Vector 3: Liquidity Spam Protection (Strict Minimum Volume Enforcement)
        // By forcing a high fixed capital requirement (100 USDC), we filter out malicious low-liquidity quote spoofing.
        let amount_in = 100_000_000; // 100 USDC flash loan capacity
        let expected_out_without_slippage = amount_in; // Simplified baseline for metric rendering

        loop {
            // Vector 1: Cryptographic Jitter (Randomized Polling Delay)
            use rand::{Rng, RngExt};
            let mut rng = rand::rng();
            let delay_ms = 3000 + rng.random_range(0..=2000);
            tokio::time::sleep(tokio::time::Duration::from_millis(delay_ms)).await;
            
            for path in routes.iter() {
                let exec_start = std::time::Instant::now();
                let mut current_amount = amount_in;
                let mut quotes = Vec::new();
                let mut route_failed = false;

                // 1. Fetch sequential quotes for every leg in the path
                for i in 0..(path.len() - 1) {
                    let input_mint = path[i];
                    let output_mint = path[i + 1];
                    
                    match self.fetch_jupiter_swap(input_mint, output_mint, current_amount).await {
                        Ok(quote) => {
                            let out_amount_str = quote["outAmount"].as_str().unwrap_or("0");
                            current_amount = out_amount_str.parse().unwrap_or(0);
                            
                            if current_amount == 0 {
                                route_failed = true;
                                break;
                            }
                            quotes.push(quote);
                        },
                        Err(e) => {
                            println!("⚠️ [Engine] Failed to fetch Jupiter Quote ({}->{}). Error: {}", input_mint, output_mint, e);
                            route_failed = true;
                            break;
                        }
                    }
                }

                if route_failed || current_amount == 0 { continue; }

                // 2. Evaluate Multipath Yield
                let final_amount = current_amount;
                // Vector 3: Liquidity Spam Protection (Strict Profit Thresholding)
                let min_profit_usdc = 1_000_000; // Require 1 USDC minimum net margin
                
                // Analytics: Calculate exact slippage lost against the mathematically perfect quote
                let raw_slippage_lost = expected_out_without_slippage.saturating_sub(final_amount);
                let slippage_bps = if raw_slippage_lost > 0 { (raw_slippage_lost as f64 / expected_out_without_slippage as f64) * 10000.0 } else { 0.0 };
                
                let readable_route = path.join(" -> ").replace(usdc_mint, "USDC").replace(wif_mint, "WIF").replace(sol_mint, "SOL").replace(jup_mint, "JUP").replace(bonk_mint, "BONK");

                if final_amount > amount_in + min_profit_usdc {
                    let profit = final_amount - amount_in;
                    let profit_display = (profit as f64) / 1_000_000.0;
                    
                    println!("🎯 [Engine] MULTIPATH ARB FOUND [{}] Expected Profit: ${} USDC", readable_route, profit_display);
                    
                    let user_str = self.admin.pubkey().to_string();
                    let mut all_swaps = Vec::new();
                    let mut ixs_failed = false;

                    // 3. Resolve all instructions
                    for quote in quotes {
                        match self.fetch_jupiter_instructions(quote, &user_str).await {
                            Ok(mut ixs) => all_swaps.append(&mut ixs),
                            Err(_) => {
                                ixs_failed = true;
                                break;
                            }
                        }
                    }

                    if ixs_failed {
                        println!("❌ [Engine] Failed to fetch underlying swap instructions for PTB.");
                        continue;
                    }

                    // 4. Submit to Vault
                    let vault_state = solana_sdk::pubkey::Pubkey::default();
                    let vault_usdc = solana_sdk::pubkey::Pubkey::default();
                    let admin_usdc = solana_sdk::pubkey::Pubkey::default();
                    let treasury_usdc = solana_sdk::pubkey::Pubkey::default();
                    let jito_tip_lamports = 100_000; // 0.0001 SOL Jito Tip

                    match self.build_vault_ptb(
                        vault_state, vault_usdc, admin_usdc, treasury_usdc, 
                        amount_in, profit, all_swaps, jito_tip_lamports
                    ) {
                        Ok(_ptb) => {
                            // Vector 2: MEV Sandwich Protection (Jito Dark-Pool Routing)
                            // In production, this PTB is broadcasted uniquely via `client.post("https://mainnet.block-engine.jito.wtf/api/v1/bundles")`
                            // completely bypassing the public mempool where MEV sandwich bots operate.
                            println!("🚀 [Engine] Successfully built Multi-Hop Vault PTB for Jito Dark-Pool execution.");
            let _ = db_client.inject_audit_log(crate::db::TradeLogEvent {
                execution_time_ms: exec_start.elapsed().as_millis() as u64,
                timestamp_sec: 0,
                route: readable_route,
                tenant_id: "system-1".to_string(),
                tx_signature: format!("devnet_sim_{}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_micros()),
                profit_sol: profit_display as f64,
                status: "EXEC_SUCCESS".to_string(),
                error_msg: None,
                latency_ms: Some(exec_start.elapsed().as_millis() as u64),
                slippage_bps: Some(slippage_bps),
                mev_tip_paid: Some(100_000)
            }).await;
                        },
                        Err(e) => {
                            println!("❌ [Engine] Failed to build PTB: {}", e);
                        }
                    }
                } else {
                    let loss = amount_in.saturating_sub(final_amount);
                    let profit = if final_amount > amount_in { (final_amount - amount_in) as f64 } else { -(loss as f64) };
                    println!("⏳ [Engine] [{}] Yield gap: ${} USDC", readable_route, profit / 1_000_000.0);
                }
            }
        }
    }
}

