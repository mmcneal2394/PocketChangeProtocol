require('dotenv').config();
const { globalArbEngine } = require('../dist/local_calc/arb_engine');
const { globalPriceBook } = require('../dist/local_calc/price_book');
const { logger } = require('../dist/utils/logger');
const fs = require('fs');

logger.info("🏁 Initiating 60-Second Micro-Amount Arbitrage Refinement Test...");

async function loop() {
    await globalArbEngine.runArbitrageScan();
}

setTimeout(async () => {
    logger.info("[BOOT] Executing initial boot test trace dynamically!");
    try {
        await globalArbEngine['executeArbitrage']({ type: 'Simple-2-Hop-Test', expectedInSol: 0.001, tipAmount: 0.002, grossProfitSol: 0, netProfit: 0, pools: [] });
    } catch (e) {
        logger.error("Initial Test Trace failed: " + e.message);
    }
}, 3000);

setInterval(loop, 1000);

setTimeout(() => {
    logger.info("✅ 60-Second Refinement Concluded. Exiting gracefully.");
    try {
        const db = require('better-sqlite3')('./trades.db');
        const row = db.prepare('SELECT COUNT(*) as c FROM trades').get();
        if (row && row.c > 0) {
            logger.info("Persisted " + row.c + " trades correctly");
        }
    } catch(e) {}
    process.exit(0);
}, 60000);
