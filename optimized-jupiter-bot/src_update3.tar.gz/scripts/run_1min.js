const { spawn, execSync } = require('child_process');

console.log("🏁 Initiating 60-Second Micro-Amount Arbitrage Refinement Test...");
const child = spawn('node', ['-r', 'ts-node/register', 'src/index.ts'], { 
    env: { ...process.env, RPC_ENDPOINT: "https://api.mainnet-beta.solana.com" },
    stdio: 'inherit'
});

setTimeout(() => {
    console.log("\n⏱️ 60 seconds elapsed. Terminating Sandbox Engine...");
    child.kill();
    console.log("📊 Tracking 'SQLite trades.db' & Running Native Refinement Analytics...");
    
    try {
        const logOutput = execSync('npx ts-node scripts/refinement_tool.ts', { encoding: 'utf-8' });
        console.log("\n==================================");
        console.log("  REFINEMENT ANALYTICS LOGS: ");
        console.log("==================================\n");
        console.log(logOutput);
    } catch(e) {
        console.error("Refinement analytics failed natively:", e.message || e);
    }
    process.exit(0);
}, 60000);
