"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var logger_1 = require("../src/utils/logger");
var transaction_1 = require("../src/execution/transaction");
var racing_1 = require("../src/execution/racing");
// Bypass internal private scopes manually mapping execution externally cleanly appropriately dynamically
function forceExecuteArbitrage(opp) {
    return __awaiter(this, void 0, void 0, function () {
        var mockIx, ix1, ix2, tipLamports, transaction, e_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 4, , 5]);
                    logger_1.logger.info("\uD83D\uDEA8 [LIVE FORCE TEST] Triggering physical Droplet compilation...");
                    logger_1.logger.info("[COMPILATION] Constructing payload for ".concat(opp.type, " with tip: ").concat(opp.tipAmount, " SOL"));
                    mockIx = {
                        programId: "JUP6LkbZbjS1jKKwapdH67yXQG3B9F2R3J5A2e8P4rPQ",
                        accounts: [{ pubkey: "11111111111111111111111111111111", isSigner: false, isWritable: false }],
                        data: "Aw=="
                    };
                    ix1 = { setupInstructions: [], swapInstruction: mockIx };
                    ix2 = { setupInstructions: [], swapInstruction: mockIx };
                    tipLamports = Math.floor(opp.tipAmount * 1e9);
                    return [4 /*yield*/, (0, transaction_1.buildVersionedTransaction)(ix1, ix2, tipLamports)];
                case 1:
                    transaction = _a.sent();
                    if (!transaction) return [3 /*break*/, 3];
                    return [4 /*yield*/, (0, racing_1.submitTransactionWithRacing)(transaction)];
                case 2:
                    _a.sent();
                    _a.label = 3;
                case 3: return [3 /*break*/, 5];
                case 4:
                    e_1 = _a.sent();
                    logger_1.logger.error("Execution failed actively: ".concat(e_1.message));
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}
var forceOpp = {
    type: 'Force-Test-Hop',
    description: 'SOL -> USDC -> SOL (SYNTHETIC ROUTE)',
    expectedInSol: 0.05,
    expectedOutSol: 0.055,
    grossProfitSol: 0.005,
    netProfit: 0.004,
    tipAmount: 0.001,
    pools: []
};
forceExecuteArbitrage(forceOpp).then(function () {
    logger_1.logger.info("✅ Live Force Test Suite Execution Completed on DigitalOcean!");
});
