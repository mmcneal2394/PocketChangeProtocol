import { createGeyserClient } from './geyser/client';
import { startGeyserListeners } from './geyser/handlers';
import { logger } from './utils/logger';

async function main() {
  logger.info('Starting Optimized Jupiter Arbitrage Bot...');

  // Start building cache
  logger.info(`Starting highly optimized JUPBOT engine using AMSTERDAM bypass...`);

  // Initialize Geyser gRPC connection
  logger.info('Connecting to Chainstack Geyser gRPC...');
  try {
    const { stream } = await createGeyserClient();
    
    logger.info('Attaching gRPC stream handlers...');
    startGeyserListeners(stream);

    logger.info('Bot is successfully running and waiting for stream updates.');

    // LIVE FORCE TEST HOOK
    const { globalArbEngine } = require('./local_calc/arb_engine');
    setInterval(() => {
        logger.info("🔥 Triggering synthetic 'Force-Hop' to validate JITO tipping/compilation mechanics dynamically...");
        const mockOpp = {
            type: 'Force-Test-Hop',
            description: 'SOL -> USDC -> SOL (SYNTHETIC ROUTE)',
            expectedInSol: 0.05,
            expectedOutSol: 0.055,
            grossProfitSol: 0.005,
            netProfit: 0.004,
            tipAmount: 0.001,
            pools: []
        };
        // @ts-ignore
        globalArbEngine['executeArbitrage'](mockOpp);
    }, 15000);

  } catch (error) {
    logger.error('Failed to start bot due to Geyser connection issue:', error);
    process.exit(1);
  }
}

main().catch((error) => {
  logger.error('Fatal unhandled exception:', error);
  process.exit(1);
});
